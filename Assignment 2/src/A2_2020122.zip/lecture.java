public interface lecture {

    public void show();
}

