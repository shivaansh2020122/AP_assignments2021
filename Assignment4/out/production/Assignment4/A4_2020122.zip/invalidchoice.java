public class invalidchoice extends RuntimeException{
    public invalidchoice(String s){
        super(s);
    }
}
