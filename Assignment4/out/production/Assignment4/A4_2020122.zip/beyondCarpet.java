public class beyondCarpet extends RuntimeException{
    public beyondCarpet(String s){
        super(s);
    }
}
