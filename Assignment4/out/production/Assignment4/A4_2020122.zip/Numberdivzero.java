public final class Numberdivzero extends ArithmeticException{
    public Numberdivzero(){
        super("This exception has been thrown due to division by zero");
    }
}
