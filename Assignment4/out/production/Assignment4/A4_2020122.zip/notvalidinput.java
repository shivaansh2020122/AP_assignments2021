public final class notvalidinput extends RuntimeException{
    public notvalidinput(String s){
        super(s);
    }
}
